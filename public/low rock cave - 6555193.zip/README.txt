low rock cave by spuzzle on Thingiverse: https://www.thingiverse.com/thing:6555193

Summary:
A lower sitting rocky cave for your small pets